# Readme Files
<<<<<<< HEAD
### Belum Responsive ya
<form action="http://google.com"><input type="submit" value="Saya Ingin Mendaftar" class="btn-daftar" /></form>
=======
### Kurang animasi
>>>>>>> 7240e353b37c8bf84c01e93eb85590224cb4bdcb
